package com.satria.login

data class Users (val name:String?)