package com.satria.login.helper

class Constant {

    companion object {
        val PREF_IS_LOGIN = "PREF_IS_LOGIN"
        val PREF_USERNAME = "PREF_USERNAME"
        val PREF_PASSWORD = "PREF_PASSWORD"
    }
}